module.exports = app => {
  const stakings = require("../controllers/staking.controller.js");

  var router = require("express").Router();

  // Create a new validator
  // router.post("/", validators.create);

  // Update a VAlidator with id
  //router.put("/:id", validators.update);

  router.get("/getallstakers/:stakerAddress", stakings.allstakers);
  
  app.use('/api/stakings', router);
};