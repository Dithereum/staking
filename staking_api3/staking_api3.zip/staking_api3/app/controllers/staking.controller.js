const db = require("../models"); // models path depend on your structure
const { Sequelize, Model, DataTypes } = require('sequelize');
const sequelize = new Sequelize('mysql::memory:');
const Staking = db.staking;

exports.create = (req, res) => {
  // Validate request
  if (!req.body.stakerAddress) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }  
 
 // stakerAddress,validatorAddress,stakeAmount,timeStamp,status,transHash,id
  // Create a Staking
  const staking = {
  		stakerAddress: req.body.stakerAddress,
  		validatorAddress: req.body.validatorAddress,
  		stakeAmount: req.body.stakeAmount,
  		timeStamp: req.body.timeStamp,
  		status: req.body.status,
  		transHash: req.body.transHash	
  }
  
  // Save staking in the database
  Staking.create(staking)
	  	.then(data =>{
	  		res.send(data);	
	  	})
	  	.catch(err =>{
	  		res.status(500).send({
	  			message: 
	  				err.message || "Some error occured while creating staking."
	  		});
	  	});	  	
  };
 
// http://localhost:9982/api/stakings/getallstakers/0x19E6277F5Cf6099BD1c54e97644EE0Dfb8bFF96c
// stakerAddress, validatorAddress, stakeAmount, timeStamp, status, transHash, id
exports.allstakers = (req,res)=>{
   var addr = req.params.stakerAddress;
   if(addr.length < 31){
   	res.send({"Error": "Please pass staker address"});
   }
   
	async function myfunction(){
		var data = {};					
		var alldata = await Staking.findAll({
			attributes: [ 'stakerAddress', 'validatorAddress', 'stakeAmount', 'timeStamp', 'status', 'transHash' ],
			where: { 'stakerAddress': addr }
		}).catch( err =>{
			res.status(500).send({
				message: err.message || "error occured retrieving details."
			})
		});		
		//console.log("All Data >>>", alldata);
		data["staking"] = alldata;
 	   if(alldata.length < 1){
   		res.send({"Error": "Record not found for given address"});
 	   }else{
			res.send(data);
		}
	}
	myfunction();
} 