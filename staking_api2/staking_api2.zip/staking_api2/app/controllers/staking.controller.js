const db = require("../models"); // models path depend on your structure
const { Sequelize, Model, DataTypes } = require('sequelize');
const sequelize = new Sequelize('mysql::memory:');
const Staking = db.staking;

console.log(">>>>>>>STAKING <<<<<<<",Staking);
exports.create = (req, res) => {
  // Validate request
  if (!req.body.stakerAddress) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }  
 
 // stakerAddress,validatorAddress,stakeAmount,timeStamp,status,transHash,id
  // Create a Staking
  const staking = {
  		stakerAddress: req.body.stakerAddress,
  		validatorAddress: req.body.validatorAddress,
  		stakeAmount: req.body.stakeAmount,
  		timeStamp: req.body.timeStamp,
  		status: req.body.status,
  		transHash: req.body.transHash	
  }
  
  // Save staking in the database
  Staking.create(staking)
	  	.then(data =>{
	  		res.send(data);	
	  	})
	  	.catch(err =>{
	  		res.status(500).send({
	  			message: 
	  				err.message || "Some error occured while creating staking."
	  		});
	  	});	  	
  };



// http://localhost:9981/api/stakings/getstaker/0x19E6277F5Cf6099BD1c54e97644EE0Dfb8bFF96c
// stakerAddress, validatorAddress, stakeAmount, timeStamp, status, transHash, id
exports.stakingdetails = (req,res)=>{
	//attributes: [ 'stakerAddress', 'status', 'stakeAmount', 'timeStamp', 'transHash' ],
	var walletToSearch = req.params.wallet.toString();
	console.log(">>>>> Getting data for req.param.wallet >>", walletToSearch, Staking);
	
	async function myfunction(){
		var data = {};
		data["delegators"] = '';
		data["staking"] = '';
		data["voting_power"] = '';
		data["total_delegators"] = '';
				
		var st = await Staking.findOne({
			where: { 'stakerAddress': req.params.wallet.toString() }
		}).catch( err =>{
			res.status(500).send({
				message: err.message || "error occured retrieving details."
			})
		});		
		data["staking"] = st; 
		//res.send(staking);
		//////-----
		var dl = await Staking.findAll({
			attributes: [ 'stakerAddress', [ 
				sequelize.fn('SUM',(sequelize.fn('COALESCE', (sequelize.col('stakeAmount')), 0))), 'sum_stake'
			]],
			group: 'stakerAddress'
		}).catch( err=>{
			res.status(500).send({
				message: err.message || "error occured retrieving details."
			})	
		});
		
		var mydelegator = [];
		dl.forEach((data) =>{
			var delegator = { "stakerAddress": data.dataValues.stakerAddress, "sum_stake": data.dataValues.sum_stake };
			//console.log("Delegator >>>>", delegator);			
			mydelegator.push(delegator);
		});
		data["delegators"] = mydelegator;
		/////----
		///~~~~
		var total_delegators = await Staking.count({
			distinct: true,
			col:'stakerAddress',
		}).catch( err=>{
				res.status(500).send({
					message: err.message || "error occured retrieving details."
				})
		});
		data["total_delegators"] = total_delegators;
		//console.log("####### >>>>>>>>> DDDCCC >>>>>>>>",total_delegators);
		///~~~~
	   ///#####
	   var voting_power = await Staking.findAll({
			attributes: [ 'stakerAddress', [ 
				sequelize.fn('SUM',(sequelize.fn('COALESCE', (sequelize.col('stakeAmount')), 0))), 'voting_power'
			]],
			where: { 'stakerAddress': req.params.wallet.toString() } 
		}).catch( err=>{
				res.status(500).send({
					message: err.message || "error occured retrieving details."
				})
		});
		data["voting_power"] = voting_power;
		///#####	
	   ///$$$$
	   var status = await Staking.findAll({
			attributes: [ 'status' ],
			order: [['id', 'DESC']],
			where: { 'stakerAddress': req.params.wallet.toString() } 
		}).catch( err=>{
				res.status(500).send({
					message: err.message || "error occured retrieving details."
				})
		});
		data["status"] = status[0].status;
		
		
		//hard coded from here -
		data["commission_rate"] = "5.00%(Update 11 months ago)";
		data["APR"] = 10.52;
		data["SELF_STAKE"] = 12000;
		data["Delegators"] = 6200;
  		data["Since_Time"] = "2021-03-15";
  		data["Operator_Address"] = "bva1z0g0cg8dkgczr6r8t6khva3srn5mwj8w5tlu7h";
		data["Self_Delegate_Address"] = "bva1z0g0cg8dkgczr6r8t6khva3srn5mwj8w5tlu7h";
		data["Consensus_Address"] = "bva1z0g0cg8dkgczr6r8t6khva3srn5mwj8w5tlu7h";
		data["Fee_Address"]= "bva1z0g0cg8dkgczr6r8t6khva3srn5mwj8w5tlu7h";
		/////$$$	 	
		res.send(data);
	}
	myfunction();
} 
 
/*   
//http://localhost:9980/api/validators/activevalidators
exports.activevalidators = (req, res)=>{
	Validator.count({
		attributes: ['validatorName'],
		group: 'validatorName',
		where: { status: "Active"}
	}).then(data =>{
		//console.log("DATA, ActiveValidators >>>", data, data.length);
		res.send({"ActiveValidators": data.length});
	}).catch(err=>{
		res.status(500).send({
				message:
         	 err.message || "Some error occurred while retrieving validators."
		});
	});
}

//http://localhost:9980/api/validators/bondedtokens
exports.bondedTokens = (req, res)=>{
	Validator.findAll({
		attributes: [
			[ 
				sequelize.fn('SUM',(sequelize.fn('COALESCE', (sequelize.col('validatorSelfStaked')), 0))), 'sum_selfstake'
			],
   		[ 
				sequelize.fn('SUM',(sequelize.fn('COALESCE', (sequelize.col('validatorDeligatorStaked')), 0))), 'sum_deligatorstake'
			],
		], 
	})
	.then(data =>{
		//console.log("sum_selfstake,sum_deligatorstake >>>",data[0].dataValues.sum_selfstake, data[0].dataValues.sum_deligatorstake);
		var bonded_tokens = parseInt(data[0].dataValues.sum_selfstake) + parseInt(data[0].dataValues.sum_deligatorstake);
		res.send({ "bonded_tokens": bonded_tokens	});
	}).catch(err=>{
		res.status(500).send({
				message:
         	 err.message || "Some error occurred while retrieving validators."
		});
	});
}

//http://localhost:9980/api/validators/getValidators
exports.getAll = (req, res)=>{
	Validator.findAll({
		attributes: [ 'validatorName', 'validatorCommission', 'validatorAPR', 'status', 'validatorSelfStaked', 'validatorDeligatorStaked' ],
	})
	.then(data =>{
		var validatorslist = [];
		data.forEach((myvalidator)=>{
			//console.log(">>>",myvalidator.dataValues);
			var vpower = parseInt(myvalidator.dataValues.validatorSelfStaked) + parseInt(myvalidator.dataValues.validatorDeligatorStaked);
			var vperc = vpower/100;
			var myob = {
					"validatorName": myvalidator.dataValues.validatorName,
					"validatorCommission": myvalidator.dataValues.validatorCommission.toString() +"%",
					"validatorAPR": myvalidator.dataValues.validatorAPR.toString() +"%",
					"status": myvalidator.dataValues.status,
					"validatorSelfStaked": myvalidator.dataValues.validatorSelfStaked,
					"validatorDeligatorStaked": myvalidator.dataValues.validatorDeligatorStaked,
					"votingpower": vpower.toString() +" / "+ vperc.toString() +"%"
			}			
			validatorslist.push(myob);
		});
		//console.log("validatorslist >>>>",validatorslist);
		res.send({ "validators_list": validatorslist });
	}).catch(err=>{
		res.status(500).send({
				message:
         	 err.message || "Some error occurred while retrieving validators."
		});
	});
}
*/