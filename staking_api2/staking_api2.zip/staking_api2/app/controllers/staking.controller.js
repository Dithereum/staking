const db = require("../models"); // models path depend on your structure
const { Sequelize, Model, DataTypes } = require('sequelize');
const sequelize = new Sequelize('mysql::memory:');
const Staking = db.staking;
const Validator = db.validator;

exports.create = (req, res) => {
  // Validate request
  if (!req.body.stakerAddress) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }  
 
 // stakerAddress,validatorAddress,stakeAmount,timeStamp,status,transHash,id
 // Create a Staking
  const staking = {
  		stakerAddress: req.body.stakerAddress,
  		validatorAddress: req.body.validatorAddress,
  		stakeAmount: req.body.stakeAmount,
  		timeStamp: req.body.timeStamp,
  		status: req.body.status,
  		transHash: req.body.transHash	
  }  
  
  // Save staking in the database
  Staking.create(staking)
	  	.then(data =>{
	  		res.send(data);	
	  	})
	  	.catch(err =>{
	  		res.status(500).send({
	  			message: 
	  				err.message || "Some error occured while creating staking."
	  		});
	  	});	  	
  };


// http://localhost:9981/api/stakings/getstaker/0x19E6277F5Cf6099BD1c54e97644EE0Dfb8bFF96c
// stakerAddress, validatorAddress, stakeAmount, timeStamp, status, transHash, id
exports.stakingdetails = (req,res)=>{
	var walletToSearch = req.params.wallet.toString();
		
	async function myfunction(){
		var data = {};
				
		var st = await Staking.findAll({
			where: { 'stakerAddress': req.params.wallet.toString() }
		}).catch( err =>{
			res.status(500).send({
				message: err.message || "Error occured retrieving details."
			})
		});		
		data["staking_tab"] = st;

		var total_delegators = await Staking.count({
			distinct: true,
			col:'stakerAddress',
		}).catch( err=>{
				res.status(500).send({
					message: err.message || "error occured retrieving details."
				})
		});
		//data["total_delegators"] = total_delegators;

		var va = await Validator.findAll({
   		attributes: [ 
   			'validatorWalletAddress', 'validatorDeligatorStaked', 
   			[ 'validatorSelfStaked', 'Voting_Power' ],
   			[ 'validatorCommission', 'Commission_Rate' ],
   			[ 'validatorAPR', 'APR' ],
   			[ 'status', 'Status' ],
   			[ 'validatorSelfStaked', 'Self_Staked' ],
   			[ 'joiningTimestamp', 'Since_Time' ],
   			[ 'validatorFeeAddress', 'Fee_Address'],
   		 ],
			where: { 'validatorWalletAddress': req.params.wallet.toString() }
		}).catch( err =>{
				res.status(500).send({
					message: err.message || "Error occured retrieving details."
				})
		}); 				
		
		va.push({ "total_delegators": total_delegators }); 
		data["left_panel"] = va;
							
	   var dl2 = await Validator.findAll({
	   	attributes: [ 	   		
	   		'validatorWalletAddress',
	   		['validatorDeligatorStaked', 'Amount' ],
	   	],
	   	where: { 'validatorWalletAddress': req.params.wallet.toString() }	
	   }).catch( err =>{
	   		res.status(500).send({
					message: err.message || "Error occured retrieving details."
				})
	   });	
		
		data["delegator_tab"] = dl2;
		res.send(data);
	}
	myfunction();
} 


