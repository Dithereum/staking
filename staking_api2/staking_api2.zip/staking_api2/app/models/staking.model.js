module.exports = (sequelize, Sequelize) => {

const Staking = sequelize.define("staking", {
	stakerAddress: {
		type: Sequelize.STRING
	},
	validatorAddress: {
		type: Sequelize.STRING 
	},
	stakeAmount: {
		type: Sequelize.BIGINT
	},
	timeStamp: {
		type: Sequelize.DATE(6)
	},
	status: {
		type: Sequelize.STRING
	},
	transHash: {
		type: Sequelize.STRING
	},
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true
	}
});
	return Staking;
};
